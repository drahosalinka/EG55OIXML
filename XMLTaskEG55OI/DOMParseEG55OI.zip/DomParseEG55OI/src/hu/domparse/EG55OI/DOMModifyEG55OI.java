package hu.domparse.EG55OI;

import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;

public class DOMModifyEG55OI {

    public static void main(String[] args) {
        try {
            // XML dokumentum betöltése
            File xmlFile = new File("XMLEG55OI.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(xmlFile);

            document.getDocumentElement().normalize();
            System.out.println("Eredeti XML dokumentum:");

            // XML kiírás a konzolra
            printDocument(document);

            // 1. Módosítás: Új megrendelés hozzáadása
            Element newOrder = document.createElement("Megrendelés");
            newOrder.setAttribute("id", "4");

            Element fizetesiMod = document.createElement("FizetésiMód");
            fizetesiMod.setTextContent("Utánvét");
            newOrder.appendChild(fizetesiMod);

            Element atvetelIdopont = document.createElement("ÁtvételIdőpontja");
            Element ev = document.createElement("év");
            ev.setTextContent("2024");
            Element honap = document.createElement("honap");
            honap.setTextContent("12");
            Element nap = document.createElement("nap");
            nap.setTextContent("25");
            atvetelIdopont.appendChild(ev);
            atvetelIdopont.appendChild(honap);
            atvetelIdopont.appendChild(nap);
            newOrder.appendChild(atvetelIdopont);

            Element tipus = document.createElement("Tipus");
            tipus.setTextContent("Magán");
            newOrder.appendChild(tipus);

            document.getDocumentElement().appendChild(newOrder);

            System.out.println("\n1. Módosítás: Új megrendelés hozzáadva.");

            // 2. Módosítás: Egy meglévő megrendelés fizetési módjának módosítása
            NodeList orders = document.getElementsByTagName("Megrendelés");
            Element firstOrder = (Element) orders.item(0); // Első megrendelés
            Node paymentNode = firstOrder.getElementsByTagName("FizetésiMód").item(0);
            paymentNode.setTextContent("Utánvét");

            System.out.println("\n2. Módosítás: Az első megrendelés fizetési módja átírva 'Utánvét'-re.");

            // 3. Módosítás: Egy meglévő szalag elem attribútumának módosítása
            NodeList ribbons = document.getElementsByTagName("Szalag");
            if (ribbons.getLength() > 0) {
                Element ribbon = (Element) ribbons.item(0); // Első szalag
                Node thicknessNode = ribbon.getElementsByTagName("Vastagság").item(0);
                thicknessNode.setTextContent("3 cm");
                System.out.println("\n3. Módosítás: Az első szalag vastagsága '3 cm'-re módosítva.");
            }

            // 4. Módosítás: Egy csokor törlése az első megrendelésből
            NodeList bouquets = firstOrder.getElementsByTagName("Csokor");
            if (bouquets.getLength() > 0) {
                Node bouquetToRemove = bouquets.item(0); // Első csokor
                firstOrder.removeChild(bouquetToRemove);
                System.out.println("\n4. Módosítás: Az első megrendelés első csokra törölve.");
            }

            // Módosított XML kiírása konzolra
            System.out.println("\nMódosított XML dokumentum:");
            printDocument(document);

            // Módosított XML mentése fájlba
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            DOMSource source = new DOMSource(document);
            StreamResult result = new StreamResult(new File("XMLNeptunkod_modified.xml"));
            transformer.transform(source, result);

            System.out.println("\nMódosítások elmentve az 'XMLNeptunkod_modified.xml' fájlba.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Segédfüggvény az XML dokumentum konzolra történő kiírásához
    private static void printDocument(Document doc) throws TransformerException {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        DOMSource source = new DOMSource(doc);
        StreamResult console = new StreamResult(System.out);
        transformer.transform(source, console);
    }
}
