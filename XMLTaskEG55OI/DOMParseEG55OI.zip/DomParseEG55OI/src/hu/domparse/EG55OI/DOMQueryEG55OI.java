package hu.domparse.EG55OI;

import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;

public class DOMQueryEG55OI {
    public static void main(String[] args) {
        try {
            // XML dokumentum betöltése
            File inputFile = new File("XMLEG55OI.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(inputFile);

            // Dokumentum normalizálása
            doc.getDocumentElement().normalize();

            System.out.println("Root elem: " + doc.getDocumentElement().getNodeName());

            // Megrendelések elem lekérdezése
            NodeList megrendelesek = doc.getElementsByTagName("Megrendelés");
            System.out.println("Megrendelések száma: " + megrendelesek.getLength());

            // 1. Lekérdezés: Megrendelők neveinek és email címeinek kiírása
            System.out.println("\n1. Megrendelők nevei és email címei:");
            for (int i = 0; i < megrendelesek.getLength(); i++) {
                Node megrendeles = megrendelesek.item(i);

                if (megrendeles.getNodeType() == Node.ELEMENT_NODE) {
                    Element elem = (Element) megrendeles;
                    String nev = elem.getElementsByTagName("Név").item(0).getTextContent();
                    String email = elem.getElementsByTagName("Email").item(0).getTextContent();
                    System.out.println("Név: " + nev + ", Email: " + email);
                }
            }

            // 2. Lekérdezés: Csokrok darabszáma megrendelésenként
            System.out.println("\n2. Csokrok darabszáma megrendelésenként:");
            for (int i = 0; i < megrendelesek.getLength(); i++) {
                Node megrendeles = megrendelesek.item(i);

                if (megrendeles.getNodeType() == Node.ELEMENT_NODE) {
                    Element elem = (Element) megrendeles;
                    NodeList csokrok = elem.getElementsByTagName("Csokor");
                    System.out.println("Megrendelés ID: " + elem.getAttribute("id") + ", Csokrok száma: " + csokrok.getLength());
                }
            }

            // 3. Lekérdezés: Csokrok árai
            System.out.println("\n3. Csokrok árai:");
            NodeList csokrok = doc.getElementsByTagName("Csokor");
            for (int i = 0; i < csokrok.getLength(); i++) {
                Node csokor = csokrok.item(i);

                if (csokor.getNodeType() == Node.ELEMENT_NODE) {
                    Element elem = (Element) csokor;
                    String id = elem.getAttribute("id");
                    String ar = elem.getElementsByTagName("Ár").item(0).getTextContent();
                    System.out.println("Csokor ID: " + id + ", Ár: " + ar + " Ft");
                }
            }

            // 4. Lekérdezés: Legdrágább csokor adatai
            System.out.println("\n4. Legdrágább csokor adatai:");
            double maxAr = 0;
            Element legdragabbCsokor = null;
            for (int i = 0; i < csokrok.getLength(); i++) {
                Node csokor = csokrok.item(i);

                if (csokor.getNodeType() == Node.ELEMENT_NODE) {
                    Element elem = (Element) csokor;
                    double ar = Double.parseDouble(elem.getElementsByTagName("Ár").item(0).getTextContent());
                    if (ar > maxAr) {
                        maxAr = ar;
                        legdragabbCsokor = elem;
                    }
                }
            }

            if (legdragabbCsokor != null) {
                System.out.println("Legdrágább csokor ID: " + legdragabbCsokor.getAttribute("id"));
                System.out.println("Ár: " + maxAr + " Ft");
                System.out.println("Alkalom: " + legdragabbCsokor.getElementsByTagName("Alkalom").item(0).getTextContent());
                System.out.println("Méret: " + legdragabbCsokor.getElementsByTagName("Méret").item(0).getTextContent());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

