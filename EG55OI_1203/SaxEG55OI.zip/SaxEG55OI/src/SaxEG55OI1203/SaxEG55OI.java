package SaxEG55OI1203;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class SaxEG55OI {

    private static int indentLevel = 0; // Szint nyomon követéséhez

    public static void main(String[] args) {
        try {
            // SAXParserFactory létrehozása
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();

            // Egyedi eseménykezelő
            DefaultHandler handler = new DefaultHandler() {

                // Behúzás létrehozása a szint alapján
                private String getIndentation() {
                    return "  ".repeat(indentLevel);
                }

                // Kezdőelem
                @Override
                public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
                    System.out.print(getIndentation() + qName + " start");

                    // Attribútumok kiírása, ha vannak
                    if (attributes.getLength() > 0) {
                        System.out.print(", {");
                        for (int i = 0; i < attributes.getLength(); i++) {
                            if (i > 0) System.out.print(", ");
                            System.out.print(attributes.getQName(i) + "=" + attributes.getValue(i));
                        }
                        System.out.print("}");
                    }

                    System.out.println();
                    indentLevel++; // Szint növelése
                }

                // Elem tartalma
                @Override
                public void characters(char[] ch, int start, int length) throws SAXException {
                    String content = new String(ch, start, length).trim();
                    if (!content.isEmpty()) {
                        System.out.println(getIndentation() + content);
                    }
                }

                // Záróelem
                @Override
                public void endElement(String uri, String localName, String qName) throws SAXException {
                    indentLevel--; // Szint csökkentése
                    System.out.println(getIndentation() + qName + " end");
                }
            };

            // XML fájl feldolgozása
            saxParser.parse("EG55OI_kurzusfelvetel.xml", handler);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
