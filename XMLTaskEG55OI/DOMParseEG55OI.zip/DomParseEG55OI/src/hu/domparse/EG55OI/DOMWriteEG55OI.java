package hu.domparse.EG55OI;

import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;

public class DOMWriteEG55OI {

    public static void main(String[] args) {
        try {
            // XML fájl betöltése
            File xmlFile = new File("XMLEG55OI.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(xmlFile);

            // Dokumentum normalizálása (a fa struktúra optimalizálása)
            document.getDocumentElement().normalize();

            // Kiíratjuk a fa struktúrát a konzolra
            System.out.println("Fa struktúra az XML dokumentumból:");
            printDocument(document);

            // Az XML fájl mentése egy új fájlba (XMLNeptunkod1.xml)
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes"); // Az XML szép formázása
            DOMSource source = new DOMSource(document);
            StreamResult result = new StreamResult(new File("XMLNeptunkod1.xml"));
            transformer.transform(source, result);

            System.out.println("\nAz XML dokumentum elmentve: XMLNeptunkod1.xml");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Segédfüggvény az XML dokumentum konzolra történő kiírásához fa struktúrában
    private static void printDocument(Document doc) throws TransformerException {
        // A gyökér elem kiírása
        NodeList nodeList = doc.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            printNode(nodeList.item(i), "  "); // A megfelelő behúzással
        }
    }

    // Rekurzív függvény, amely kiírja a csomópontokat fa struktúrában
    private static void printNode(Node node, String indent) {
        // Ha a csomópont elem, kiírjuk annak nevét és értékét
        if (node.getNodeType() == Node.ELEMENT_NODE) {
            System.out.println(indent + "Element: " + node.getNodeName());
            if (node.hasAttributes()) {
                NamedNodeMap attributes = node.getAttributes();
                for (int i = 0; i < attributes.getLength(); i++) {
                    Node attribute = attributes.item(i);
                    System.out.println(indent + "  Attribute: " + attribute.getNodeName() + " = " + attribute.getNodeValue());
                }
            }
        }

        // Ha a csomópont szöveg, kiírjuk az értékét
        if (node.getNodeType() == Node.TEXT_NODE) {
            String text = node.getTextContent().trim();
            if (!text.isEmpty()) {
                System.out.println(indent + "Text: " + text);
            }
        }

        // Rekurzívan hívjuk a gyerek csomópontokat, ha vannak
        if (node.hasChildNodes()) {
            NodeList childNodes = node.getChildNodes();
            for (int i = 0; i < childNodes.getLength(); i++) {
                printNode(childNodes.item(i), indent + "  "); // További behúzás
            }
        }
    }
}
