package xpathEG55OI1119;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.xpath.*;
import java.io.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

public class XPathModify {
    public static void main(String[] args) {
        try {
            // Load the XML document
            File inputFile = new File("orarendNeptunkod.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(inputFile);

            // Create XPath expression object
            XPathFactory xpathFactory = XPathFactory.newInstance();
            XPath xpath = xpathFactory.newXPath();

            // 1. Modify the name of the "szak" element (course name)
            String szakXpath = "/DA_orarend/ora/szak";
            NodeList szakNodes = (NodeList) xpath.evaluate(szakXpath, doc, XPathConstants.NODESET);
            for (int i = 0; i < szakNodes.getLength(); i++) {
                Node szakNode = szakNodes.item(i);
                if (szakNode.getTextContent().equals("Korszeru Webtechnologiak")) {
                    szakNode.setTextContent("Modern Web Technologies");
                }
            }

            // 2. Add a monogram to the subject name (e.g., "Adatkezeles XML-ben" becomes "Adatkezeles XML-ben (DA)")
            String targyXpath = "/DA_orarend/ora/targy";
            NodeList targyNodes = (NodeList) xpath.evaluate(targyXpath, doc, XPathConstants.NODESET);
            for (int i = 0; i < targyNodes.getLength(); i++) {
                Node targyNode = targyNodes.item(i);
                String subject = targyNode.getTextContent();
                if (subject.equals("Adatkezeles XML-ben")) {
                    targyNode.setTextContent(subject + " (DA)");
                }
            }

            // 3. Change the location (helyszin) of the ora element with id=3
            String oraXpath = "/DA_orarend/ora[@id='03']/helyszin";
            Node helyszinNode = (Node) xpath.evaluate(oraXpath, doc, XPathConstants.NODE);
            if (helyszinNode != null) {
                helyszinNode.setTextContent("XXXVII");
            }

            // Print the modified document to the console
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource(doc);
            StreamResult consoleResult = new StreamResult(System.out);
            transformer.transform(source, consoleResult);

            // Save the modified document to a new file
            File outputFile = new File("modified_orarend.xml");
            StreamResult fileResult = new StreamResult(outputFile);
            transformer.transform(source, fileResult);

            System.out.println("\nChanges applied and saved to modified_orarend.xml.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
