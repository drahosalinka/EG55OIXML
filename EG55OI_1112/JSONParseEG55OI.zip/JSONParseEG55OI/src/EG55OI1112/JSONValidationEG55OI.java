package EG55OI1112;

import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class JSONValidationEG55OI {

    public static void main(String[] args) {
        try {
            // Betöltjük a sémát
            FileInputStream schemaStream = new FileInputStream("orarendJSONSchemaNeptunkod.json");
            JSONObject rawSchema = new JSONObject(new JSONTokener(schemaStream));
            Schema schema = SchemaLoader.load(rawSchema);

            // Betöltjük a validálandó JSON fájlt
            FileInputStream jsonStream = new FileInputStream("orarendNeptunkod.json");
            JSONObject json = new JSONObject(new JSONTokener(jsonStream));

            // Validáljuk a JSON-t
            schema.validate(json);

            System.out.println("A JSON fájl sikeresen validált a séma alapján.");
        } catch (FileNotFoundException e) {
            System.err.println("A fájl nem található: " + e.getMessage());
        } catch (org.everit.json.schema.ValidationException e) {
            System.err.println("A JSON fájl nem felel meg a sémának: " + e.getMessage());
            e.getCausingExceptions().forEach(exc -> System.err.println(" - " + exc.getMessage()));
        } catch (Exception e) {
            System.err.println("Hiba történt a JSON fájl validálása során: " + e.getMessage());
        }
    }
}
