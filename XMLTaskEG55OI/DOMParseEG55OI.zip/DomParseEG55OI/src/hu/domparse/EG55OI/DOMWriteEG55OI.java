package hu.domparse.EG55OI;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class DOMWriteEG55OI {
    public static void main(String[] args) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.newDocument();
            
            // Virágbolt DOM fa felépítése
            createFlowerShopOrders(document);
            
            // Kiírás konzolra és fájlba
            File newXmlFile = new File("XMLEG55OI.xml");
            StreamResult xmlToWrite = new StreamResult(newXmlFile);
            writeDocument(document, xmlToWrite); // Írás fájlba
            StreamResult console = new StreamResult(System.out);
            System.out.println("A felépített dokumentum:\n");
            writeDocument(document, console); // Kiírás konzolra
            
        } catch (ParserConfigurationException | TransformerException | DOMException e) {
            e.printStackTrace();
        }
    }
    
    private static void createFlowerShopOrders(Document document) throws DOMException {
        // Gyökérelem felvétele
        Element root = document.createElement("Megrendelések");
        document.appendChild(root);

        // Első megrendelés
        root.appendChild(document.createComment("Első megrendelés"));
        Element firstOrder = createOrder(document, "1", "Bankkártya", "2024", "12", "6", "Magán", "24000");
        createBouquet(document, firstOrder, "Esküvő", "Közepes", new String[][] {
            {"Rózsa", "Vörös, Fehér", "8", "Közepes"},
            {"Lizianthusz", "Fehér", "10", "Kicsi"},
            {"Szegfű", "Vörös", "3", "Közepes"},
            {"Szegfű", "Fehér", "5", "Közepes"}
        }, "Arany", "2 cm", "500");
        root.appendChild(firstOrder);

        // Második megrendelés
        root.appendChild(document.createComment("Második megrendelés"));
        Element secondOrder = createOrder(document, "2", "Készpénz", "2024", "12", "2", "Magán", "16000");
        createBouquet(document, secondOrder, "Koszorúslány csokor", "Kis", new String[][] {
            {"Lizianthusz", "Fehér", "5", "Kicsi"},
            {"Szegfű", "Vörös", "2", "Közepes"},
            {"Szegfű", "Fehér", "4", "Kicsi"}
        }, "Piros", "2 cm", "450");
        root.appendChild(secondOrder);

        // Harmadik megrendelés
        root.appendChild(document.createComment("Harmadik megrendelés"));
        Element thirdOrder = createOrder(document, "3", "Átutalás", "2024", "12", "18", "Céges", "12000");
        createBouquet(document, thirdOrder, "Céges vacsora", "Kis", new String[][] {
            {"Lizianthusz", "Rózsaszín", "3", "Kis"},
            {"Orchidea", "Fehér", "6", "Kis"},
            {"Rózsa", "Rózsaszín", "9", "Közepes"}
        }, "Fehér", "2 cm", "450");
        root.appendChild(thirdOrder);
    }

    // Új megrendelés elem készítése
    private static Element createOrder(Document document, String orderId, String paymentMethod, String year, String month, String day, String type, String total) {
        Element orderElement = document.createElement("Megrendelés");
        orderElement.setAttribute("id", orderId);

        // Fizetési mód
        orderElement.appendChild(createTextElement(document, "FizetésiMód", paymentMethod));

        // Átvétel időpontja
        Element pickupElement = document.createElement("ÁtvételIdőpontja");
        pickupElement.appendChild(createTextElement(document, "év", year));
        pickupElement.appendChild(createTextElement(document, "honap", month));
        pickupElement.appendChild(createTextElement(document, "nap", day));
        orderElement.appendChild(pickupElement);

        // Típus és végösszeg
        orderElement.appendChild(createTextElement(document, "Tipus", type));
        orderElement.appendChild(createTextElement(document, "Végösszeg", total));

        return orderElement;
    }

    // Virágcsokor elem készítése
 // Inside the createBouquet method:
    private static void createBouquet(Document document, Element orderElement, String occasion, String size, String[][] flowers, String ribbonColor, String ribbonThickness, String ribbonPrice) {
        Element bouquetElement = document.createElement("Csokor");
        bouquetElement.setAttribute("id", String.valueOf(orderElement.getChildNodes().getLength() + 1));
        
        bouquetElement.appendChild(createTextElement(document, "Alkalom", occasion));
        bouquetElement.appendChild(createTextElement(document, "Méret", size));
        
        // Virágok hozzáadása
        for (String[] flower : flowers) {
            Element flowerElement = document.createElement("Virág");
            flowerElement.appendChild(createTextElement(document, "Fajta", flower[0]));
            
            // Handle multiple colors (split the color string if necessary)
            String[] colors = flower[1].split(",");  // Assuming colors are comma-separated
            for (String color : colors) {
                flowerElement.appendChild(createTextElement(document, "Szín", color.trim())); // Add each color directly as a separate <Szín> element
            }
            
            flowerElement.appendChild(createTextElement(document, "darab", flower[2]));
            flowerElement.appendChild(createTextElement(document, "Méret", flower[3]));
            bouquetElement.appendChild(flowerElement);
        }

        
        // Szalag
        Element ribbonElement = document.createElement("Szalag");
        ribbonElement.appendChild(createTextElement(document, "Szín", ribbonColor));
        ribbonElement.appendChild(createTextElement(document, "Vastagság", ribbonThickness));
        ribbonElement.appendChild(createTextElement(document, "Méterár", ribbonPrice));
        bouquetElement.appendChild(ribbonElement);
        
        // Csokor hozzáadása a megrendeléshez
        orderElement.appendChild(bouquetElement);
    }


    // Új szöveges elem készítése
    private static Element createTextElement(Document document, String tagName, String textContent) {
        Element element = document.createElement(tagName);
        element.appendChild(document.createTextNode(textContent));
        return element;
    }
    
    // Dokumentum kiírása konzolra és fájlba
    public static void writeDocument(Document document, StreamResult output) throws TransformerException {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer;
        transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        
        DOMSource source = new DOMSource(document);
        transformer.transform(source, output);
    }
}
