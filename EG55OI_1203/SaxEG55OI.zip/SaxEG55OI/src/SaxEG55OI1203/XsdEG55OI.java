package SaxEG55OI1203;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.File;

public class XsdEG55OI {
    public static void main(String[] args) {
        try {
            // XML és XSD fájlok betöltése
            File xmlFile = new File("EG55OI_kurzusfelvetel.xml");
            File xsdFile = new File("EG55OI_kurzusfelvetel.xsd");
            
            // XSD validáció konfigurálása
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = factory.newSchema(xsdFile);
            Validator validator = schema.newValidator();
            
            // XML validálása
            validator.validate(new StreamSource(xmlFile));
            System.out.println("XSD Validation successful");
        } catch (Exception e) {
            System.out.println("Validation failed: " + e.getMessage());
        }
    }
}
