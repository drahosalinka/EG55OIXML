/**
 * 
 */
/**
 * 
 */
module JSONParseEG55OI {
	requires json.simple;
	requires java.xml;
}