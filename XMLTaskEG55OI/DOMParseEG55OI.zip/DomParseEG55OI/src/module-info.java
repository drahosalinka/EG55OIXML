/**
 * 
 */
/**
 * 
 */
module DomParseEG55OI {
	requires java.xml;
}