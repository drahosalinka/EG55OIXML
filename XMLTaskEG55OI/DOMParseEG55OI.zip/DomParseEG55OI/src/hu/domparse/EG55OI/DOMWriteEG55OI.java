package hu.domparse.EG55OI;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class DOMWriteEG55OI {
    public static void main(String[] args) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.newDocument();
            
            // Virágbolt DOM fa felépítése
            createFlowerShopOrders(document);
            
            // Kiírás konzolra és fájlba
            File newXmlFile = new File("XMLEG55OI.xml");
            StreamResult xmlToWrite = new StreamResult(newXmlFile);
            writeDocument(document, xmlToWrite); // Írás fájlba
            StreamResult console = new StreamResult(System.out);
            System.out.println("A felépített dokumentum:\n");
            writeDocument(document, console); // Kiírás konzolra
            
        } catch (ParserConfigurationException | TransformerException | DOMException e) {
            e.printStackTrace();
        }
    }
    
    private static void createFlowerShopOrders(Document document) throws DOMException {
        // Root element
        Element root = document.createElement("Megrendelések");
        document.appendChild(root);

        // First order
        root.appendChild(document.createComment("Első megrendelés"));
        Element firstOrder = createOrder(document, "1", "Bankkártya", "2024", "12", "6", "Magán", 
            new String[][][] {
                { // Bouquet 1
                    {"Esküvő", "24000", "Közepes"},
                    {"Rózsa", "Vörös,Fehér", "8", "Közepes"},
                    {"Lizianthusz", "Fehér", "10", "Kicsi"},
                    {"Szegfű", "Vörös,Cirka", "3", "Közepes"},
                    {"Szegfű", "Fehér", "5", "Közepes"},
                    {"Arany", "2 cm", "500"}
                },
                { // Bouquet 2
                    {"Koszorúslány csokor", "16000", "Kis"},
                    {"Lizianthusz", "Fehér", "5", "Kicsi"},
                    {"Szegfű", "Vörös", "2", "Közepes"},
                    {"Szegfű", "Fehér", "4", "Kicsi"},
                    {"Piros", "2 cm", "450"}
                },
                { // Bouquet 3
                    {"Koszorúslány csokor", "16000", "Kis"},
                    {"Lizianthusz", "Fehér", "5", "Kicsi"},
                    {"Szegfű", "Vörös", "4", "Közepes"},
                    {"Szegfű", "Fehér", "2", "Kicsi"},
                    {"Piros", "2 cm", "450"}
                }
            });
        root.appendChild(firstOrder);

        // Second order
        root.appendChild(document.createComment("Második megrendelés"));
        Element secondOrder = createOrder(document, "2", "Készpénz", "2024", "12", "2", "Magán",
            new String[][][] {
                { // Bouquet 4
                    {"Diplomaosztó", "17000", "Nagy"},
                    {"Hortenzia", "Kék", "3", "Nagy"},
                    {"Hortenzia", "Lila", "3", "Nagy"},
                    {"Liliom", "Rózsaszín,Sárga", "7", "Közepes"},
                    {"Rózsaszín", "3 cm", "700"}
                }
            });
        root.appendChild(secondOrder);

        // Third order
        root.appendChild(document.createComment("Harmadik megrendelés"));
        Element thirdOrder = createOrder(document, "3", "Átutalás", "2024", "12", "18", "Céges",
            new String[][][] {
                { // Bouquet 5
                    {"Céges vacsora", "12000", "Kis"},
                    {"Lizianthus", "Rózsaszín", "3", "Kis"},
                    {"Orchidea", "Fehér", "6", "Kis"},
                    {"Rózsa", "Rózsaszín", "9", "Közepes"},
                    {"Fehér", "2 cm", "450"}
                },
                { // Bouquet 6
                    {"Céges vacsora", "12000", "Kis"},
                    {"Lizianthusz", "Fehér", "3", "Kis"},
                    {"Kála", "Sárga,Fehér", "6", "Kis"},
                    {"Rózsa", "Sárga", "9", "Közepes"},
                    {"Sárga", "2 cm", "450"}
                }
            });
        root.appendChild(thirdOrder);
    }


    // Új megrendelés elem készítése
    private static Element createOrder(Document document, String orderId, String paymentMethod, String year, String month, String day, String type, String[][][] bouquets) {
        Element orderElement = document.createElement("Megrendelés");
        orderElement.setAttribute("id", orderId);

        // Payment Method
        orderElement.appendChild(createTextElement(document, "FizetésiMód", paymentMethod));

        // Pickup Time
        Element pickupElement = document.createElement("ÁtvételIdőpontja");
        pickupElement.appendChild(createTextElement(document, "év", year));
        pickupElement.appendChild(createTextElement(document, "honap", month));
        pickupElement.appendChild(createTextElement(document, "nap", day));
        orderElement.appendChild(pickupElement);

        // Type
        orderElement.appendChild(createTextElement(document, "Tipus", type));

        // Add Bouquets
        int bouquetId = 1; // Start with bouquet ID 1
        for (String[][] bouquet : bouquets) {
            createBouquet(document, orderElement, bouquetId++, bouquet);
        }

        return orderElement;
    }

    //Virágcsokor elem
    private static void createBouquet(Document document, Element orderElement, int bouquetId, String[][] bouquetDetails) {
        Element bouquetElement = document.createElement("Csokor");
        bouquetElement.setAttribute("id", String.valueOf(bouquetId));

        // Basic Bouquet Details
        bouquetElement.appendChild(createTextElement(document, "Alkalom", bouquetDetails[0][0]));
        bouquetElement.appendChild(createTextElement(document, "Ár", bouquetDetails[0][1]));
        bouquetElement.appendChild(createTextElement(document, "Méret", bouquetDetails[0][2]));

        // Flowers
        for (int i = 1; i < bouquetDetails.length - 1; i++) {
            String[] flower = bouquetDetails[i];
            Element flowerElement = document.createElement("Virág");
            flowerElement.appendChild(createTextElement(document, "Fajta", flower[0]));
            for (String color : flower[1].split(",")) {
                flowerElement.appendChild(createTextElement(document, "Szín", color.trim()));
            }
            flowerElement.appendChild(createTextElement(document, "Méret", flower[3]));
            flowerElement.appendChild(createTextElement(document, "darab", flower[2]));
            bouquetElement.appendChild(flowerElement);
        }

        // Ribbon
        String[] ribbon = bouquetDetails[bouquetDetails.length - 1];
        Element ribbonElement = document.createElement("Szalag");
        ribbonElement.appendChild(createTextElement(document, "Szín", ribbon[0]));
        ribbonElement.appendChild(createTextElement(document, "Vastagság", ribbon[1]));
        ribbonElement.appendChild(createTextElement(document, "Méterár", ribbon[2]));
        bouquetElement.appendChild(ribbonElement);

        orderElement.appendChild(bouquetElement);
    }



    // Új szöveges elem készítése
    private static Element createTextElement(Document document, String tagName, String textContent) {
        Element element = document.createElement(tagName);
        element.appendChild(document.createTextNode(textContent));
        return element;
    }
    
    // Dokumentum kiírása konzolra és fájlba
    public static void writeDocument(Document document, StreamResult output) throws TransformerException {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer;
        transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        
        DOMSource source = new DOMSource(document);
        transformer.transform(source, output);
    }
}
