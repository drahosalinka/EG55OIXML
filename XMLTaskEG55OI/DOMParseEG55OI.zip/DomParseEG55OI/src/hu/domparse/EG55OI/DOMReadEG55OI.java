package hu.domparse.EG55OI;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class DOMReadEG55OI {

    public static void main(String[] args) {
        try {
            // Az XML fájl betöltése
            File inputFile = new File("XMLEG55OI.xml");
            // Dokumentumépítő létrehozása
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            // Az XML dokumentum elemfává alakítása
            Document document = builder.parse(inputFile);
            document.getDocumentElement().normalize();

            // Az XML gyökérelemének kiolvasása
            Element root = document.getDocumentElement();
            System.out.println("Gyökérelem: " + root.getNodeName());
            System.out.println("====================================");

            // Gyermek elemek feldolgozása
            NodeList orders = document.getElementsByTagName("Megrendelés");

            // Konzol kimenet előállítása
            StringBuilder output = new StringBuilder();
            for (int i = 0; i < orders.getLength(); i++) {
                Node orderNode = orders.item(i);

                if (orderNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element order = (Element) orderNode;

                    // Megrendelés azonosító kiírása
                    String orderId = order.getAttribute("id");
                    output.append("Megrendelés ID: ").append(orderId).append("\n");

                    // Fizetési mód kiírása
                    String paymentMethod = getElementValue(order, "FizetésiMód");
                    output.append("  Fizetési mód: ").append(paymentMethod).append("\n");

                    // Átvételi időpont
                    Element pickupDate = (Element) order.getElementsByTagName("ÁtvételIdőpontja").item(0);
                    String year = getElementValue(pickupDate, "év");
                    String month = getElementValue(pickupDate, "honap");
                    String day = getElementValue(pickupDate, "nap");
                    output.append("  Átvétel időpontja: ").append(year).append("-").append(month).append("-").append(day).append("\n");

                    // Megrendelő adatai
                    Element customer = (Element) order.getElementsByTagName("Megrendelő").item(0);
                    String name = getElementValue(customer, "Név");
                    String email = getElementValue(customer, "Email");
                    String phone = getElementValue(customer, "Telefon");
                    output.append("  Megrendelő:\n");
                    output.append("    Név: ").append(name).append("\n");
                    output.append("    Email: ").append(email).append("\n");
                    output.append("    Telefon: ").append(phone).append("\n");

                    // Csokrok feldolgozása
                    NodeList bouquets = order.getElementsByTagName("Csokor");
                    for (int j = 0; j < bouquets.getLength(); j++) {
                        Node bouquetNode = bouquets.item(j);

                        if (bouquetNode.getNodeType() == Node.ELEMENT_NODE) {
                            Element bouquet = (Element) bouquetNode;
                            output.append("  Csokor ID: ").append(bouquet.getAttribute("id")).append("\n");
                            output.append("    Alkalom: ").append(getElementValue(bouquet, "Alkalom")).append("\n");
                            output.append("    Ár: ").append(getElementValue(bouquet, "Ár")).append("\n");
                            output.append("    Méret: ").append(getElementValue(bouquet, "Méret")).append("\n");

                            // Virágok feldolgozása
                            NodeList flowers = bouquet.getElementsByTagName("Virág");
                            for (int k = 0; k < flowers.getLength(); k++) {
                                Element flower = (Element) flowers.item(k);
                                output.append("      Virág: ").append(getElementValue(flower, "Fajta")).append("\n");
                                output.append("        Szín: ").append(getElementValue(flower, "Szín")).append("\n");
                                output.append("        Méret: ").append(getElementValue(flower, "Méret")).append("\n");
                                output.append("        Darab: ").append(getElementValue(flower, "darab")).append("\n");
                            }

                            // Szalag adatok feldolgozása
                            Element ribbon = (Element) bouquet.getElementsByTagName("Szalag").item(0);
                            output.append("    Szalag:\n");
                            output.append("      Szín: ").append(getElementValue(ribbon, "Szín")).append("\n");
                            output.append("      Vastagság: ").append(getElementValue(ribbon, "Vastagság")).append("\n");
                            output.append("      Méterár: ").append(getElementValue(ribbon, "Méterár")).append("\n");
                        }
                    }
                    output.append("====================================\n");
                }
            }

            // Kimenet a konzolra
            System.out.println(output.toString());

            // Adatok mentése fájlba
            try (FileWriter writer = new FileWriter("ProcessedOrders.txt")) {
                writer.write(output.toString());
            }
            System.out.println("Adatok sikeresen mentve a 'ProcessedOrders.txt' fájlba.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Segédfüggvény egy elem szöveges tartalmának kiolvasására
    private static String getElementValue(Element parent, String tagName) {
        NodeList nodeList = parent.getElementsByTagName(tagName);
        if (nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        }
        return "";
    }
}

